# Live Markdown & Diagram Studio (Rich Internet Application)

A fast, zero-backend-required Rich Internet Application (RIA) featuring live Markdown parsing, real-time **Mermaid.js** flowchart/sequence diagram rendering, local auto-save, URL-encoded instant sharing, HTML/PDF export, and optional **Firebase Firestore** cloud sync. Ready for 1-click deployment on **Vercel** or **Firebase Hosting**.

## Features
- **Live Split-Pane Editor:** Instant Markdown rendering with tables, blockquotes, and syntax-styled code blocks.
- **Mermaid.js Diagram Engine:** Render architecture flowcharts and sequence diagrams live inside Markdown fences.
- **Zero-Backend Shareable Links:** Compresses document state directly into a shareable `?data=` URL parameter.
- **Optional Firebase Firestore Sync:** Add `.env` keys to persist and share short `?id=` cloud links.
- **Export Ready:** One-click standalone `.html` download and print-optimized PDF export.

## Local Setup
```bash
npm install
npm run dev
```

## Deploy to Vercel
1. Push this folder to a GitHub repository (or install Vercel CLI: `npm i -g vercel`).
2. Run `vercel` in the project root, or import the repo on [vercel.com](https://vercel.com).
3. `vercel.json` is preconfigured for Single Page Application (SPA) routing.

## Deploy to Firebase Hosting
1. Install Firebase CLI: `npm install -g firebase-tools`
2. Build the production bundle: `npm run build`
3. Initialize & deploy:
   ```bash
   firebase login
   firebase init hosting # select existing project, set public dir to 'dist'
   firebase deploy
   ```
